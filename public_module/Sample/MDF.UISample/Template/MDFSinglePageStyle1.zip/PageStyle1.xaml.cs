﻿using MDF.Framework;
using MDF.MES.ControlSL.MDF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : PageBase
    {
        public $safeitemname$()
        {
            InitializeComponent();

            this.Loaded += $safeitemname$_Loaded;
        }

        void $safeitemname$_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = new MDF.MES.BusinessControlSL.EntityBusinessVM<$fileinputname$>(
                this, 
                this.Resources["queryItemList"] as QueryItemList);
        }
    }
}
